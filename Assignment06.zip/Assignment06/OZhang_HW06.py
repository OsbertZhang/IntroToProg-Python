#-------------------------------------------------#
# Title: Working with Functions and Classes
# Dev:   Osbert Zhang
# Date:  May 7th, 2018
# ChangeLog: (Who, When, What)
#   Osbert Zhang, 05/07/2018,
#   Manipulated Original Script for HW06 to
#   demonstrate knowledge of functions and classes

#-------------------------------------------------#

#-------------------------------------------------#
# Original Code Source from Professor R. Root

# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  Sept 16, 2017
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, Created Script

#-------------------------------------------------#


class todoTasks(object):
    """Created a class todoTasks to group all functions relating to manipulating To Do List"""
    @staticmethod
    def loadFile():
        """Function to load file from txt and create a list"""
        lstTable = []
        objFile = open("C:\_PythonClass\Todo.txt", "r")
        for line in objFile:
            strData = line.split(",")  # readline() reads a line of the data into 2 elements
            dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return lstTable

    @staticmethod
    def menu():
        """Display menu of options"""
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)

    @staticmethod
    def displayList(lstTable):
        """Function to display contents of To Do List"""
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod
    def addTask(lstTable):
        """Function to add a task to the To Do List"""
        strTask = str(input("What is the task to add? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        return lstTable

    @staticmethod
    def delTask(lstTable):
        """Function to delete a task to the To Do List"""
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")
        return lstTable

    @staticmethod
    def saveList(lstTable):
        """Function to save To Do List"""
        if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open("C:\_PythonClass\Todo.txt", "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")

def main():
    """Main function to run program"""
    tdList = todoTasks.loadFile()
    while(True):
        todoTasks.menu()

        strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
        print()#adding a new line

        # Step 3 -Show the current items in the table
        if (strChoice.strip() == '1'):
            todoTasks.displayList(tdList)
            continue
        # Step 4 - Add a new item to the list/Table
        elif(strChoice.strip() == '2'):
            tdList = todoTasks.addTask(tdList)
            todoTasks.displayList(tdList)
            continue
        # Step 5 - Remove a new item to the list/Table
        elif(strChoice == '3'):
            tdList = todoTasks.delTask(tdList)
            todoTasks.displayList(tdList)
            continue
        # Step 6 - Save tasks to the ToDo.txt file
        elif(strChoice == '4'):
            todoTasks.saveList(tdList)
            continue
        elif (strChoice == '5'):
            break #and Exit the program



#start the program
main()
input("\n\nPress the enter key to quit.")



